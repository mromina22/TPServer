#!/bin/bash
# --- VARIABLES --- #
ORIGEN="$1"
NOMBRE="$2"

# --- MOSTRAR MENU AYUDA --- #
if [[ "$1" == "-help" ]]; then
	echo "Guia de uso de backup: $0 <directorio_origen> <directorio_de_destino>"
	exit 0
fi

# --- BACKUP --- #
FECHA=$(date +%Y%m%d)
DESTINO="/backup_dir/${Nombre}_bkp_${FECHA}.tar.gz"
tar -czf "$DESTINO" "$ORIGEN"
echo "Backup creado correctamente: $DESTINO  "

# --- VALIDACION DE ORIGEN Y DESTINO --- #
if [ ! -d "$ORIGEN" ]; then
	echo "ERROR: el directorio de origen no existe."
	exit 1
fi

if [ ! -d "/backup_dir" ]; then
	echo "ERROR: el directorio /backup_dir no esta disponible."
	exit 1
fi
